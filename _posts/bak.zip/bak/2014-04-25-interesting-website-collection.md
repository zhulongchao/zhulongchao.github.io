---
layout: post
title: 有趣、好玩、有料的网站收藏
categories: [资源集合]
tags: 整理
---

本来想给自己做得独有的导航的，不过一直没时间折腾，先把本小子觉得有趣、好玩、有料的站点收藏起来。这些站点本小子会经常光顾，主要是一些学习进阶方面的站点。

## 前端

[HTML5资源教程](http://www.html5tricks.com/)：分享HTML5开发资源和开发教程

[w3cschool](http://www.w3cschool.cc/)：主要学习CSS3、Bootstrap、Python、jQ

## 机器学习库

[scikit-learn](http://scikit-learn.org/stable/)：Python机器学习库

[SimpleCV](http://simplecv.org/)：Computer Vision platform using Python

[CVpapers](http://www.cvpapers.com/index.html)：Computer Vision Resource

## 游戏开发

[Pygame写游戏](http://eyehere.net/2011/python-pygame-novice-professional-index/)：用Python和Pygame写游戏-从入门到精通