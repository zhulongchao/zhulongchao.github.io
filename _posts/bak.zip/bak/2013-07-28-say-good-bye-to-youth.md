---
layout: post
title: 知行手记：青春散场
categories: [Life]
tags: 大学
---

>我们就这样，各自奔天涯。

---
<object width="526" height="374">
<param name="movie" value="http://player.youku.com/player.php/sid/XNTc3NzQ0NTQw/v.swf"></param>
<param name="allowFullScreen" value="true" />
<param name="allowScriptAccess" value="always"/>
<param name="wmode" value="transparent"></param>
<param name="bgColor" value="#ffffff"></param>
<embed src="http://player.youku.com/player.php/sid/XNTc3NzQ0NTQw/v.swf" allowFullScreen="true" quality="high" width="480" height="400" align="middle" allowScriptAccess="always" type="application/x-shockwave-flash"></embed>
</object>

---

## 起程

2013年6月29日，再过一天，便不再属于西电这片朴实的土地。4年，在走的时候，总觉得该为那些陪自己一路走来关心的和被关心的朋友留下些什么。明日一散，来日不知何时相聚（相逢应该会是常有的吧，一次能够把所有的朋友聚到一起，估计有难度(~~~~(>_<)~~~~ )。

![2013-06-20-graduation3](http://yuanyong.org/blog/public/images/posts/2013-06-20-graduation3.png)

## 感情深，一口闷
临近离校的这十来天，每天早晨起来，看着这几个睡相惨不忍睹的室友，心中满是感伤，再也不会有这么几个人，陪我生活学习四年，吃喝玩睡在同一个屋子里。



海棠I区505 我们四年的家园

左                                                                                                 右

候大象（国相O(∩_∩)O~）     汤荡荡（旭国(*^__^*) ）                    俊宇      涛哥（教你打dota）

超哥                                     袁大头（民国时我是财富的象征哦）     晓阳      （愤怒的）小强
怎么概括陪我生活了四年的这帮爷们(清嗓子中...还有羞涩少年)呢，两个字，“大爷”，三个字，“你大爷”（O(∩_∩)O哈哈~）。生活了四年，这帮爷们还是挺够仗义的。作为一枚文弱书生(羞涩中)，虽然未能有幸病上一场，以享得这帮爷们端茶倒水的待遇，但有大事情的时候，这帮爷们便倾尽力量使出各自风骚（“各领风骚数百年”）的看家本领。四年很长，仍然习惯不了大半夜dota的游戏声和寝室垃圾堆满墙角的惨象；六月太短，我还是喜欢看着这帮爷们玩游戏玩得很high的样子。曾近的小磨檫、小欢乐、小忧伤都化为六月天空里的云雨，清凉了一季的夏天。

![2013-06-20-graduation2]({{ site.url }}/images/posts/2013-06-20-graduation2.png)

作为一个矛盾的组合体，我常常生活在否定与肯定的两种极端里。就像此刻我对自己以前做过的觉得很有意义的事满是否定一样，然而，能够与你们这帮爷们、沙沙、201、小班的同学和在F楼实验室结识的好友，却从未有过否定。
光机所半年身心巨疲的折磨（是不是磨练依然未知），让我很是怀疑大学所作的努力是有意义的，我越来越疑惑自己到底喜欢做什么了，未来三年的路的尽头，一片迷茫。现在想来，大学最值得肯定的还是你们。最近找到刘若英的《亲爱的路人》，很喜欢里面的歌词：

>那时候 年轻得不甘寂寞  
错把磨练当成折磨  
对的人终于会来到  
因为 犯的错够多  
总要为 想爱的人不想活  
才跟该爱的人生活  
......
