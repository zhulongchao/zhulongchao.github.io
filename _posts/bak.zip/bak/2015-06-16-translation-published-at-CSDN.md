---
layout: post
title: 技术翻译：不要低估最近邻算法(译)
categories: [翻译]
tags: 翻译
---

上周周日下午接了篇CSDN周老师发放下来的英文博文[Otto Product Classification Winner's Interview: 2nd place, Alexander Guschin](http://blog.kaggle.com/2015/06/09/otto-product-classification-winners-interview-2nd-place-alexander-guschin/)，翻译得比较顺手，晚上又稍微校审了之后便发给了周老师，没想到这么快就在CSDN云计算首页和大家见面了[Otto产品分类挑战赛亚军：不要低估最近邻算法](http://www.csdn.net/article/2015-06-16/2824981)，恰巧今天小白菜生日，留个痕迹纪念一下。

![clustering]({{ site.url }}/images/posts/2015-06-16/translation.png)

谢谢周老师的再次校正，以及涛哥在小白菜校审过程中给予的帮助。


