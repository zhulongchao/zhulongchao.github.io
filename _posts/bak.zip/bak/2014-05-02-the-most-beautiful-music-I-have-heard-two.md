---
layout: post
title: 广陵绝艺：我曾听过最美的音乐(二)
categories: [Life]
tags: 音乐
---

刷秋秋空间时从[那些花儿](http://user.qzone.qq.com/374847236)老师那听来了宫崎骏又一好听的钢琴曲，[Touched By Your Tenderness](http://www.kuwo.cn/yinyue/234218/)，听后充满了慢慢的宁静和平感。先挖个坑，有时间了再把本小子对这首歌的感受写下来。
