---
layout: post
title: 机器学习：算法搜藏，不定期更新
categories: [Machine Learning]
tags: 机器学习
---

搜寻代码的时候常会碰见一些前面碰到过有用的代码，这些代码可以在以前碰到的场景中有用，也可能在往后的研究中会有用，私藏一些，以供后用。

- 超分算法。这个前一段时间实验室boss发邮件，邮件中还附带一些分辨率很低的图像，他让我们超分一下。嗯，Semi-Coupled Dictionary Learning for Super-Resolution，CVPR12，私藏一个[**代码**](https://github.com/wsl3000666/SCDL)  