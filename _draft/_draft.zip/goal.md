1. Writing a book about image retrieval
2. Finish the project of BoVW
3. Reading the source code of Caffe
