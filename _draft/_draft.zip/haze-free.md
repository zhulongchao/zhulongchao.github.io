https://github.com/JinweiClarkChao/DCP/tree/master/DCP
https://github.com/l1nxy/haze-remove
