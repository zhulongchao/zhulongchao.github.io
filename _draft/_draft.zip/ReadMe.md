待写文章

- caffe python多进程多卡提取特征(finished)
- Falconn之局部敏感哈希, PQ, IVF-PQ
- caffe c++ 提取特征、批量提取特征
- MSER+X图像指纹
- PCA对CDW的影响
