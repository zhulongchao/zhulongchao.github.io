车辆分类问题

[车辆分类数据库CompCars](http://mmlab.ie.cuhk.edu.hk/datasets/comp_cars/index.html)，The Comprehensive Cars (CompCars) dataset。

[CompCar_Analysis](https://github.com/nicklhy/CompCar_Analysis)，参考代码。

[A Large-Scale Car Dataset for Fine-Grained Categorization and Verification
](http://mmlab.ie.cuhk.edu.hk/datasets/comp_cars/CompCars.pdf).
